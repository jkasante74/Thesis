package ipd;

public class Scores {

	

/**
 * This method calculates the payoffs associated with the selected actions
 * @param agentsActions
 * @return
 */

public static int [] calcAgentsScores(char[] agentsActions) {
	int scoreA = 0, scoreB = 0;
	int []matchScores = new int[2];
	
	if((agentsActions[0]=='C')&&(agentsActions[1]=='C')){
		scoreA = 3; 
		scoreB = 3;
	}
	
	if((agentsActions[0]=='C')&&(agentsActions[1]=='D')){
		scoreA = 0; 
		scoreB = 5;
	}
	
	if((agentsActions[0]=='D')&&(agentsActions[1]=='C')){
		scoreA = 5; 
		scoreB = 0;
	}
	
	if((agentsActions[0]=='D')&&(agentsActions[1]=='D')){
		scoreA = 1; 
		scoreB = 1;
	}
	
	matchScores[0] = scoreA;
	matchScores[1] = scoreB;
	
	System.out.println(matchScores[0] +"\t \t vrs \t \t" + matchScores[1]);
	return matchScores;
}
	
	
	
	
	
	
}
