package ipd;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.GridLayout;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JSplitPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;

public class RulesSetup {

	private JFrame frmSetup;
	private JTextField txtPlayerNum;
	private JTextField txtTournament;
	private JTextField txtTempt;
	private JTextField txtReward;
	private JTextField txtSucker;
	private JTextField txtPunishment;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RulesSetup window = new RulesSetup();
					window.frmSetup.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RulesSetup() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSetup = new JFrame();
		frmSetup.setBounds(100, 100, 283, 396);
		frmSetup.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSetup.getContentPane().setLayout(new GridLayout(1, 0, 0, 0));
		
		JPanel panel = new JPanel();
		frmSetup.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(22, 17, 238, 282);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNumberOfPlayers = new JLabel("Number of Players");
		lblNumberOfPlayers.setForeground(UIManager.getColor("Button.shadow"));
		lblNumberOfPlayers.setBounds(6, 23, 148, 16);
		panel_1.add(lblNumberOfPlayers);
		lblNumberOfPlayers.setHorizontalAlignment(SwingConstants.LEFT);
		
		JLabel lblTournaments = new JLabel("Tournaments");
		lblTournaments.setForeground(UIManager.getColor("Button.shadow"));
		lblTournaments.setHorizontalAlignment(SwingConstants.LEFT);
		lblTournaments.setBounds(6, 65, 148, 16);
		panel_1.add(lblTournaments);
		
		JLabel lblTemptationPayoff = new JLabel("Temptation PayOff");
		lblTemptationPayoff.setForeground(UIManager.getColor("Button.shadow"));
		lblTemptationPayoff.setHorizontalAlignment(SwingConstants.LEFT);
		lblTemptationPayoff.setBounds(6, 107, 148, 16);
		panel_1.add(lblTemptationPayoff);
		
		JLabel lblRewardPayoff = new JLabel("Reward PayOff");
		lblRewardPayoff.setForeground(UIManager.getColor("Button.shadow"));
		lblRewardPayoff.setHorizontalAlignment(SwingConstants.LEFT);
		lblRewardPayoff.setBounds(6, 149, 148, 16);
		panel_1.add(lblRewardPayoff);
		
		JLabel lblPunishmentPayoff = new JLabel("Punishment PayOff");
		lblPunishmentPayoff.setForeground(UIManager.getColor("Button.shadow"));
		lblPunishmentPayoff.setHorizontalAlignment(SwingConstants.LEFT);
		lblPunishmentPayoff.setBounds(6, 233, 148, 16);
		panel_1.add(lblPunishmentPayoff);
		
		JLabel lblSuckerPayoff = new JLabel("Sucker's PayOff");
		lblSuckerPayoff.setForeground(UIManager.getColor("Button.shadow"));
		lblSuckerPayoff.setHorizontalAlignment(SwingConstants.LEFT);
		lblSuckerPayoff.setBounds(6, 191, 148, 16);
		panel_1.add(lblSuckerPayoff);
		
		txtPlayerNum = new JTextField();
		txtPlayerNum.setBounds(176, 17, 44, 28);
		panel_1.add(txtPlayerNum);
		txtPlayerNum.setColumns(10);
		
		txtTournament = new JTextField();
		txtTournament.setColumns(10);
		txtTournament.setBounds(176, 59, 44, 28);
		panel_1.add(txtTournament);
		
		txtTempt = new JTextField();
		txtTempt.setColumns(10);
		txtTempt.setBounds(176, 101, 44, 28);
		panel_1.add(txtTempt);
		
		txtReward = new JTextField();
		txtReward.setColumns(10);
		txtReward.setBounds(176, 143, 44, 28);
		panel_1.add(txtReward);
		
		txtSucker = new JTextField();
		txtSucker.setColumns(10);
		txtSucker.setBounds(176, 185, 44, 28);
		panel_1.add(txtSucker);
		
		txtPunishment = new JTextField();
		txtPunishment.setColumns(10);
		txtPunishment.setBounds(176, 227, 44, 28);
		panel_1.add(txtPunishment);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(22, 311, 243, 50);
		panel.add(panel_3);
		panel_3.setLayout(null);
		
		JButton btnSave = new JButton("Save");
		btnSave.setBounds(6, 6, 65, 38);
		panel_3.add(btnSave);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmSetup.dispose();
			}
		});
		btnCancel.setBounds(83, 6, 72, 38);
		panel_3.add(btnCancel);
		
		JButton btnDefault = new JButton("Default");
		btnDefault.setBounds(167, 6, 72, 38);
		panel_3.add(btnDefault);
	}
}
