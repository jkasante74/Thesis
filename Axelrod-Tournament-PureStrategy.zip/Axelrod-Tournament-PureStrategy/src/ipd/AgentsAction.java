package ipd;

public class AgentsAction {

	/**
	 * Get the actions associated with the strategies of the agents in the current match
	 * @param object
	 * @param object2
	 * @param strategy
	 */
	 Strategies stra = new Strategies();
	Project1 pro = new Project1();
	public static char[] getAgentsActions(int t, int cRound, Object object, Object object2, String[] strategy) {
		char [] actions = new char[2];
		String a = strategy[(Integer.parseInt((String)object) - 1)];
		String b = strategy[(Integer.parseInt((String)object2) - 1)];
		int agentId = (Integer.parseInt((String)object) - 1);
		int agentOppId = (Integer.parseInt((String)object2) - 1);
		System.out.println(a +"\t vrs \t" + b);
		
		// get the Action
		char actionA, actionB;
			 
		switch (a) {
			case "CooperateAll": actionA = Strategies.cooperateAll(agentOppId); break;
			case "DefectAll": 	actionA = Strategies.defectAll(agentOppId); break;
			case "TitForTat":	actionA = Strategies.TitForTat(cRound, agentId, agentOppId); break;
			case "Random": actionA = Strategies.random( agentOppId) ; break;
			case "Pavlov": actionA = Strategies.PAVLOV(cRound, agentId,agentOppId); break;
			case "GrimTrigger": actionA = Strategies.grimTrigger(agentId,agentOppId);  break;
			default: throw new RuntimeException("Bad argument passed to makePlayer");
		}
			 
		switch (b) {
		case "CooperateAll": actionB = Strategies.cooperateAll(agentId); break;
		case "DefectAll": 	actionB = Strategies.defectAll(agentId); break;
		case "TitForTat":	actionB = Strategies.TitForTat(cRound, agentOppId, agentId); break;
		case "Random": actionB =Strategies.random(agentId) ; break;
		case "Pavlov": actionB = Strategies.PAVLOV(cRound, agentOppId,agentId); break;
		case "GrimTrigger": actionB = Strategies.grimTrigger(agentOppId,agentId);  break;
		default: throw new RuntimeException("Bad argument passed to makePlayer");
		}	 
			 actions[0] = actionA;   // agentId
			 actions[1] = actionB;   // agentOppId
			 
			 System.out.println(actions[0] +"\t \t vrs \t \t" + actions[1]);	// Print actions of agents and competition
		
		// Store the actions of the agents in the Action database
			 Project1.agentActionsDbase[t][agentOppId][agentId] = actionA; 
			 Project1.agentActionsDbase[t][agentId][agentOppId] = actionB; 
			 
			 
		return actions;
	}
	
	
}
