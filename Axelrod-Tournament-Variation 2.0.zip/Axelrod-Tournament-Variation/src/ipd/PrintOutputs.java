package ipd;

public class PrintOutputs {

	public static void printTourn(int t){
		System.out.println("TOURNAMENT "+ (t+1));
    	System.out.println("=============================");
	}
	
	public static void printChosenStrategies(){
		System.out.println("Randomly chosen Strategies ");
		System.out.println("=============================");
		
		// Print the randomly selected Strategies
		for(int t = 0; t < Project1.teams; t++){
			System.out.println("Player "+ (t+1) + "\t"+Project1.Strategy[t]);
		}
	}

	
	// Print the leader Board
	public static void printLeaderBoard(){
		System.out.println("LEADER BOARD");
		System.out.println("=============================");
		for(int i = (Project1.data.length-1); i >= 0;i--){
			System.out.printf("%-20s%-30s%-30s", Project1.data[i][0], Project1.data[i][1], Project1.data[i][2]);
			System.out.println();
		}
	}                              
  
	
	
    // Let's print the actions taken by all agents
	public static void printAgentsActions(){
		for(int h = 0; h < Project1.tourn; h++){
			for(int i = 0; i < Project1.teams; i++){
				for(int j=0 ; j < Project1.teams; j++)
					System.out.print(Project1.agentActionsDbase[h][i][j]+ "\t");
				System.out.println();
			}
			System.out.println("\n");
		}
	}
	
	
	
	
	
	
	
	
}
