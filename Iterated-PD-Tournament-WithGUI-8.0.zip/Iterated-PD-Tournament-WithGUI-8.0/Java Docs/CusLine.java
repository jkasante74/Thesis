/**
 * 
 * This code was adopted and modified from 
 * http://www.advsofteng.com/doc/cdjavadoc/simpleline.htm
 */
package externalSystem;

import org.jfree.chart.ChartPanel; 
import org.jfree.chart.JFreeChart; 
import org.jfree.data.xy.XYDataset; 
import org.jfree.ui.ApplicationFrame; 
import org.jfree.ui.RefineryUtilities; 
import org.jfree.chart.ChartFactory; 
import org.jfree.chart.plot.PlotOrientation; 
import org.jfree.data.xy.XYSeriesCollection; 

public class CusLine extends ApplicationFrame 
{
	/**
	 * Variable declaration and initialization
	 */
	private static final long serialVersionUID = 1L;
	public static final XYSeriesCollection dataset = new XYSeriesCollection( );
	
	
   public CusLine( String frameTitle, String chartTitle )
   {
      super(frameTitle);
      JFreeChart xylineChart = ChartFactory.createXYLineChart(
         chartTitle ,
         "Round" ,
         "Pay-Off" ,
         createDataset() ,
         PlotOrientation.VERTICAL ,
         true , true , false);	//Plot Graph
         
      ChartPanel chartPanel = new ChartPanel( xylineChart );
      chartPanel.setPreferredSize( new java.awt.Dimension( 560 , 367 ) );
      setContentPane( chartPanel ); 
   }
   
   private XYDataset createDataset( )
   {
      return dataset;
   }

   public static void main( String[ ] args ) 
   {
      CusLine chart = new CusLine("Line Graph of Pay-Off Vs Rounds", " ");
      chart.pack( );  // resize the window to fit the graph        
      RefineryUtilities.centerFrameOnScreen( chart );  // display chart on center screen
      chart.setVisible( true ); // show the chart
   }
}