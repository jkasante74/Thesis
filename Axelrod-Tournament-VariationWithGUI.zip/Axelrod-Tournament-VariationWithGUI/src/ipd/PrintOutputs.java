package ipd;

public class PrintOutputs {

	/**
	 * This method prints the heading for the current Tournament played
	 * @param t
	 */
	public static String message = "";
	public static String message1 = "";
	
	
	public static void printTourn(int t){
		System.out.println("\nROUND-ROBIN TOURNAMENT "+ (t+1));
    	System.out.println("===================");
    	String str = "\nROUND-ROBIN TOURNAMENT "+ (t+1) +"\n"+ "===================\n";
    	SimGame.textSimResults.append(str);
	}
	
	/**
	 * This method prints the heading of Randomly chosen strategies
	 */
	public static void printChosenStrategies(){
		System.out.println("\nRandomly chosen Strategies ");
		System.out.println("=============================");
		
		// Print the randomly selected Strategies
		for(int t = 0; t < Project1.teams; t++){
			message = message + "Player "+ (t+1) + "\t "+Project1.Strategy[t] + "\n";
			System.out.println("Player "+ (t+1) + "\t "+Project1.Strategy[t]);
			SimGame.randStrategy = message;
			
		}
		
		message = "";
	}

	
	/**
	 * This method prints the Leader Board showing players, their randomly chosen strategies 
	 * and the total pay-offs at the end of the tournament. 
	 */
	public static void printLeaderBoard(){
		System.out.println("LEADER BOARD (Variation of IPD)");
		System.out.println("=================================");
		for(int i = (Project1.data.length-1); i >= 0;i--){
			message1 = message1 + Project1.data[i][0] + "\t" + Project1.data[i][1] + "\t" +  Project1.data[i][2] + "\n";
			SimGame.leadBoard = message1;
			System.out.printf("%-20s%-30s%-30s", Project1.data[i][0], Project1.data[i][1], Project1.data[i][2]);
			System.out.println();
		}
		message1 = "";
	}                              
  
	
	
    /**
     * Let's print the actions taken by all agents
     */
	public static void printAgentsActions(){
		for(int h = 0; h < Project1.tourn; h++){
			for(int i = 0; i < Project1.teams; i++){
				for(int j=0 ; j < Project1.teams; j++)
					System.out.print(Project1.agentActionsDbase[h][i][j]+ "\t");
				System.out.println();
			}
			System.out.println("\n");
		}
	}
	
	
	
	
	
	
	
	
}
