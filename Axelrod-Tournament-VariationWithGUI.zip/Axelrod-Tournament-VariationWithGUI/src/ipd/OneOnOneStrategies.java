package ipd;

import java.util.Random;

public class OneOnOneStrategies {
	public static char actionA;
	
	public static char oppAction(String a){
		if(a.equalsIgnoreCase("CooperateAll")) 
			actionA = cooperateAll(); 
		if(a.equalsIgnoreCase("DefectAll"))  	
			actionA = defectAll();
	
	if(a.equalsIgnoreCase("Random")) 
		actionA = random();
	/*
	if(a.equalsIgnoreCase("TitForTat"))	
		actionA = TitForTat(cRound, agentId, agentOppId);
	if(a.equalsIgnoreCase("Pavlov")) 
		actionA = PAVLOV(cRound, agentId,agentOppId);
	if(a.equalsIgnoreCase("GrimTrigger")) 
		actionA = grimTrigger(agentId,agentOppId); 
	*/
		return actionA;
	
	}
	public static char grimTrigger(int agentid, int oppId ) {
		
		
		
		// create an array of strategies
		// before selection of c or d get the opponent id
		char grimSelection;
		if (Project1.grimTriggerHist[agentid][oppId]=='D')
			grimSelection = 'D';
			
		else
			grimSelection = 'C';
			
		return grimSelection;
	}



/**
* This method describes the PAVLOV Strategy. 
* The idea here is that the agent repeat last choice if good outcome - 
* If 5 or 3 points scored in the last round then repeat 
* last choice.
* @param n
* @param oppId
* @return
*/
static char PAVLOV(int n, int agentId, int oppId) {
	char pavlovChoioce;
		
	if ((n==0)&&(Project1.pavlovChoiceHist[agentId][oppId]== 0)){
		pavlovChoioce = 'C';	//cooperate by default
		return pavlovChoioce;
	}
	
	if(Project1.pavlovScoreHist[agentId][oppId] >= 3){
		pavlovChoioce = Project1.pavlovChoiceHist[agentId][oppId];
		return pavlovChoioce;
	}
		
	else{
		if(Project1.pavlovChoiceHist[agentId][oppId]=='C')
			pavlovChoioce = 'D';
		else
			pavlovChoioce = 'C';
		
		return pavlovChoioce;
	}
}

	



/**
* This method describes the TitForTat Strategy 
* Cooperate at the first play; then,
* on subsequent plays, mimic the action
* the other player chose on the immediately 
* preceding play
* @param n
* @param oppId
* @return
*/

static char TitForTat(int n, int agentId, int oppId) {
	char TFT;
			
	if (Project1.titForTatHist[agentId][oppId]=='D')
		TFT = 'D';
		
	else
		TFT= 'C';
			
	return TFT;
		
}

	
/**
* This method describes the Defect all Strategy. 
* Here, an defect at all times no matter what the opponent does
* @return char
 */
static char defectAll(){
			
	return 'D';
}
		
	


/**
* This method describes the Corporate All Strategy. 
* Here an agent cooperate at all times no matter what the opponent does
* @return char
*/
static char cooperateAll(){
	
return 'C';
}




/**
* This method describes the Random Strategy. 
* Here an agent chooses to Cooperate or Defect based on a randomly generated 
* floating point number between 0 and 1. 
* If random number < 0.5, then the agent cooperate, else the agent defects
* @return
*/
static char random(){
	
	// Generate a random number to determine whether to cooperate or defect
	if (Math.random() < 0.5)
			return 'C';  //cooperates half the time
		else
			return 'D';  //defects half the time
}






public static void updateStrategies(int scA, int scB) {
	
	//Update the Grim Trigger History for all Agents
	if(Project1.grimTriggerHist[(scA-1)][(scB-1)] !='D') //Update opponent history action only if existing action is Coorporate
		if(Project1.Strategy[(scA-1)].equalsIgnoreCase("GrimTrigger")){
			Project1.grimTriggerHist[(scA-1)][(scB-1)]=Project1.agentsActions[1];
	}
	
	if(Project1.grimTriggerHist[(scB-1)][(scA-1)] !='D')
	if(Project1.Strategy[(scB-1)].equalsIgnoreCase("GrimTrigger")){
		Project1.grimTriggerHist[(scB-1)][(scA-1)] = Project1.agentsActions[0];
	}
	
	//Update the TitForTat History for all Agents
	if(Project1.Strategy[(scA-1)].equalsIgnoreCase("TitForTat")){
		Project1.titForTatHist[(scA-1)][(scB-1)]=Project1.agentsActions[1];
	}
	
	if(Project1.Strategy[(scB-1)].equalsIgnoreCase("TitForTat")){
		Project1.titForTatHist[(scB-1)][(scA-1)]=Project1.agentsActions[0];
	}
	
	//Update the PAVLOV History for all Agents
	if(Project1.Strategy[(scA-1)].equalsIgnoreCase("Pavlov")){
		Project1.pavlovChoiceHist[(scA-1)][(scB-1)] = Project1.agentsActions[0];
		Project1.pavlovScoreHist[(scA-1)][(scB-1)]=Project1.agentsMatchScores[0];
	}
	
	if(Project1.Strategy[(scB-1)].equalsIgnoreCase("Pavlov")){
		Project1.pavlovChoiceHist[(scB-1)][(scA-1)] = Project1.agentsActions[1];
		Project1.pavlovScoreHist[(scB-1)][(scA-1)] = Project1.agentsMatchScores[1];
	}
	
}


public static void updateActionDatabase(int t, Object object, Object object2, char [] actions){
	char actionA, actionB;	
	
	  actionA = actions[0];   // agentId
	  actionB = actions[1];   // agentOppId
	int agentId = (Integer.parseInt((String)object) - 1);
	int agentOppId = (Integer.parseInt((String)object2) - 1);
	// Store the actions of the agents in the Action database
	 Project1.agentActionsDbase[t][agentOppId][agentId] = actionA; 
	 Project1.agentActionsDbase[t][agentId][agentOppId] = actionB; 
	 
}
	
	
	
}
