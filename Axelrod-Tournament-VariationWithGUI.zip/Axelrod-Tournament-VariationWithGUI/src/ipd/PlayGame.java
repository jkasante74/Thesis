package ipd;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Color;

import javax.swing.JTable;
import javax.swing.border.LineBorder;

import java.awt.Font;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class PlayGame {

	private JFrame frmPlayGame;
	private JTextField txtRound;
	public static String Round;
	public static int counter=1;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PlayGame window = new PlayGame();
					window.frmPlayGame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PlayGame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPlayGame = new JFrame();
		frmPlayGame.setTitle("Play Game");
		frmPlayGame.setBounds(100, 100, 658, 682);
		frmPlayGame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPlayGame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel.setBounds(16, 16, 301, 328);
		frmPlayGame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel label_5 = new JLabel("5 , 0");
		label_5.setHorizontalAlignment(SwingConstants.CENTER);
		label_5.setBounds(120, 266, 50, 16);
		panel.add(label_5);
		
		JLabel label_4 = new JLabel("0 , 5");
		label_4.setHorizontalAlignment(SwingConstants.CENTER);
		label_4.setBounds(211, 220, 50, 16);
		panel.add(label_4);
		
		JLabel label_6 = new JLabel("1 , 1");
		label_6.setHorizontalAlignment(SwingConstants.CENTER);
		label_6.setBounds(211, 266, 50, 16);
		panel.add(label_6);
		
		JLabel label_3 = new JLabel("3 , 3");
		label_3.setHorizontalAlignment(SwingConstants.CENTER);
		label_3.setBounds(120, 220, 50, 16);
		panel.add(label_3);
		
		JLabel lblInstructions = new JLabel("INSTRUCTIONS");
		lblInstructions.setBounds(6, 16, 107, 16);
		panel.add(lblInstructions);
		
		JLabel lblPlayTheVariation = new JLabel("<html>Play the variation of the Iterated Prisoner's Dilemma against your choice from six (6) different personalities. <br><br> You will be playing the game with the default payoff specified below</html>");
		lblPlayTheVariation.setBounds(6, 44, 279, 108);
		lblPlayTheVariation.setHorizontalAlignment(SwingConstants.CENTER);
		lblPlayTheVariation.setForeground(Color.GRAY);
		lblPlayTheVariation.setVerticalAlignment(SwingConstants.TOP);
		panel.add(lblPlayTheVariation);
		
		JLabel label = new JLabel("INSTRUCTIONS");
		label.setBounds(6, 16, 107, 16);
		panel.add(label);
		
		JLabel lblOpponent = new JLabel("Opponent");
		lblOpponent.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 13));
		lblOpponent.setHorizontalAlignment(SwingConstants.CENTER);
		lblOpponent.setBounds(130, 164, 107, 16);
		panel.add(lblOpponent);
		
		final JComboBox<Object> cmbOpponent = new JComboBox<Object>();
		
		JLabel lblYou = new JLabel("You");
		lblYou.setFont(new Font("Lucida Grande", Font.BOLD | Font.ITALIC, 13));
		lblYou.setHorizontalAlignment(SwingConstants.CENTER);
		lblYou.setBounds(6, 249, 50, 16);
		panel.add(lblYou);
		
		JLabel lblCooperate = new JLabel("Cooperate");
		final JButton btnDefect = new JButton("Defect");
		btnDefect.setEnabled(false);
		btnDefect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String counterString = Integer.toString(counter);
				if(counter <= Integer.parseInt(Round)){
					String []info = {counterString, "D", cmbOpponent.getSelectedItem().toString()};
					OneOnOne.main(info);
					counter++;
				}
			}
		});
		
		lblCooperate.setHorizontalAlignment(SwingConstants.CENTER);
		lblCooperate.setBounds(100, 192, 89, 16);
		panel.add(lblCooperate);
		
		JLabel lblDefect = new JLabel("Defect");
		lblDefect.setHorizontalAlignment(SwingConstants.CENTER);
		lblDefect.setBounds(201, 192, 71, 16);
		panel.add(lblDefect);
		
		JLabel label_1 = new JLabel("Cooperate");
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setBounds(24, 221, 89, 16);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("Defect");
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setBounds(42, 266, 71, 16);
		panel.add(label_2);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel_1.setBounds(329, 16, 311, 626);
		frmPlayGame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(155, 6, 0, 16);
		panel_1.add(textArea);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setBounds(6, 43, 299, 577);
		panel_1.add(textArea_1);
		
		JLabel lblResults = new JLabel("RESULTS");
		lblResults.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		lblResults.setForeground(Color.BLUE);
		lblResults.setHorizontalAlignment(SwingConstants.CENTER);
		lblResults.setBounds(6, 6, 299, 16);
		panel_1.add(lblResults);
		
		JLabel lblyoutt = new JLabel("<html>You </html> ");
		lblyoutt.setHorizontalAlignment(SwingConstants.LEFT);
		lblyoutt.setForeground(Color.RED);
		lblyoutt.setBounds(95, 21, 60, 16);
		panel_1.add(lblyoutt);
		
		JLabel lblopponent = new JLabel("<html>Opponent </html> ");
		lblopponent.setHorizontalAlignment(SwingConstants.LEFT);
		lblopponent.setForeground(Color.RED);
		lblopponent.setBounds(225, 21, 80, 16);
		panel_1.add(lblopponent);
		
		JLabel lblRound_1 = new JLabel("Round");
		lblRound_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblRound_1.setForeground(Color.RED);
		lblRound_1.setBounds(6, 21, 60, 16);
		panel_1.add(lblRound_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel_2.setBounds(16, 356, 301, 156);
		frmPlayGame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		final JButton btnCooperate = new JButton("Cooperate");
		btnCooperate.setEnabled(false);
		
		
		JLabel lblChoooseOpponent = new JLabel("<html>Chooose Opponent</html>");
		lblChoooseOpponent.setHorizontalAlignment(SwingConstants.CENTER);
		lblChoooseOpponent.setBounds(6, 6, 88, 41);
		panel_2.add(lblChoooseOpponent);
		
		
		cmbOpponent.setModel(new DefaultComboBoxModel<Object>(new String[] {"CooperateAll", "DefectAll", "GrimTrigger", "PAVLOV", "Random", "TitForTat"}));
		cmbOpponent.setBounds(149, 20, 146, 27);
		panel_2.add(cmbOpponent);
		
		final JButton btnPlayGame = new JButton("Play");
		btnPlayGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnPlayGame.setEnabled(false);
				cmbOpponent.setEnabled(false);
				btnCooperate.setEnabled(true);
				btnDefect.setEnabled(true);
				Round = txtRound.getText();
				txtRound.setEnabled(false);
				
			}
		});
		btnPlayGame.setBounds(94, 115, 54, 35);
		panel_2.add(btnPlayGame);
		
		JButton btnStop = new JButton("Stop");
		btnStop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnPlayGame.setEnabled(true);
				cmbOpponent.setEnabled(true);
				btnCooperate.setEnabled(false);
				btnDefect.setEnabled(false);
				txtRound.setEnabled(true);
				
			}
		});
		btnStop.setBounds(170, 115, 54, 35);
		panel_2.add(btnStop);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmPlayGame.dispose();
				String[] args = null;
				FirstView.main(args);
			}
		});
		btnExit.setBounds(248, 115, 54, 35);
		panel_2.add(btnExit);
		
		JLabel lblRound = new JLabel("Number of Rounds");
		lblRound.setHorizontalAlignment(SwingConstants.LEFT);
		lblRound.setBounds(6, 61, 132, 41);
		panel_2.add(lblRound);
		
		txtRound = new JTextField();
		txtRound.setText("10");
		txtRound.setBounds(159, 67, 134, 28);
		panel_2.add(txtRound);
		txtRound.setColumns(10);
		
		
		
		
		
		
		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel_3.setBounds(16, 524, 301, 118);
		frmPlayGame.getContentPane().add(panel_3);
		
		btnCooperate.setBounds(18, 47, 117, 47);
		panel_3.add(btnCooperate);
		
		btnDefect.setBounds(160, 47, 117, 47);
		panel_3.add(btnDefect);
		
		JLabel lblplay = new JLabel("<html>Play</html>");
		lblplay.setHorizontalAlignment(SwingConstants.LEFT);
		lblplay.setBounds(6, 6, 88, 25);
		panel_3.add(lblplay);
		btnCooperate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String counterString = Integer.toString(counter);
				if(counter <= Integer.parseInt(Round)){
					String []info = {counterString, "C", cmbOpponent.getSelectedItem().toString()};
					OneOnOne.main(info);
					counter++;
				}
			
			}
		});
	}
}
