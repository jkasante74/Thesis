package ipd;

public class OneOnOneScores {
/*
	public static int temptation = 5;
	public static int reward = 3;
	public static int sucker = 0;
	public static int punishment = 1;
*/
	
	public static int temptation = RulesSetup.myTemp;
	public static int reward = RulesSetup.myReward;
	public static int sucker = RulesSetup.mySucker;
	public static int punishment = RulesSetup.myPunishment;
/**
 * This method calculates the payoffs associated with the selected actions
 * @param agentsActions
 * @return
 */

	public static int [] calcAgentsScores(char[] agentsActions) {
		int scoreA = 0, scoreB = 0;
		int []matchScores = new int[2];
	
		if((agentsActions[0]=='C')&&(agentsActions[1]=='C')){
			scoreA = reward; 
			scoreB = reward;
		}
	
		if((agentsActions[0]=='C')&&(agentsActions[1]=='D')){
			scoreA = sucker; 
			scoreB = temptation;
		}
	
		if((agentsActions[0]=='D')&&(agentsActions[1]=='C')){
			scoreA = temptation; 
			scoreB = sucker;
		}
	
		if((agentsActions[0]=='D')&&(agentsActions[1]=='D')){
			scoreA = punishment; 
			scoreB = punishment;
		}
	
		matchScores[0] = scoreA;
		matchScores[1] = scoreB;
	
		System.out.println(matchScores[0] +"\t \t vrs \t \t" + matchScores[1]);
		String act = matchScores[0] +"\t vrs \t" + matchScores[1]+ "\n\n\n";
	     SimGame.textSimResults.append(act);
		return matchScores;
	}
	
	
	public static int [] countAgentActions(String action) {
		int [] Actions = new int[2];
		int cooperateCount = 0, defectCount = 0;
		
		for(int i= 0; i < action.length(); i++){
			if (action.charAt(i)=='C')
				cooperateCount++;
			if (action.charAt(i)=='D')
				defectCount++;
		}
		
		Actions[0] = cooperateCount;
		Actions[1] = defectCount++;
		
		return Actions;
		
	}


	
	
	
}
