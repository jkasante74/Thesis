package ipd;

public class OneOnOne {

	public static int rNum;
	public static String oppAgent;
	public static String playerAction;
	public static void main(String[] args) {
		
		
		
		// Get opponent action
		char oppAct = OneOnOneStrategies.oppAction(args[2]);
		
		System.out.println(args[0]+ "\t"+args[1]+"\t"+oppAct);
		
	}
}
	