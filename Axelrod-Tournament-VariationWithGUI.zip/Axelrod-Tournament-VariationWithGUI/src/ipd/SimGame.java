package ipd;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Color;

import javax.swing.JTable;
import javax.swing.border.LineBorder;

import java.awt.Font;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

public class SimGame {

	private JFrame frmSimGame;
	private JTextField txtPlayerNum;
	private JTextField txtTournNum;
	public static int myPlayNum;
	public static int myTournNum;
	public static String randStrategy;
	public static String leadBoard;
	public static JTextArea textSimResults = new JTextArea();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SimGame window = new SimGame();
					window.frmSimGame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SimGame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSimGame = new JFrame();
		frmSimGame.setResizable(false);
		frmSimGame.setTitle("Simulation");
		frmSimGame.setBounds(100, 100, 790, 641);
		frmSimGame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSimGame.getContentPane().setLayout(null);
	
		final JTextArea txtArea1 = new JTextArea(5, 16);
		txtArea1.setForeground(new Color(221, 160, 221));

		final JTextArea txtLeader = new JTextArea(5, 16);
		txtLeader.setForeground(new Color(189, 183, 107));
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel_1.setBounds(315, 16, 469, 588);
		frmSimGame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(155, 6, 0, 16);
		panel_1.add(textArea);
		
		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel_3.setBounds(16, 172, 287, 434);
		
		JScrollPane scrollPane_2 = new JScrollPane(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane_2.setBounds(6, 40, 457, 542);
		panel_1.add(scrollPane_2);
		textSimResults.setForeground(new Color(105, 105, 105));
		textSimResults.setFont(new Font("Lucida Grande", Font.PLAIN, 12));
		
		
		scrollPane_2.setViewportView(textSimResults);
		
		JLabel lblsimulationResults = new JLabel("<html>Simulation Results </html>");
		lblsimulationResults.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		lblsimulationResults.setForeground(Color.RED);
		lblsimulationResults.setHorizontalAlignment(SwingConstants.CENTER);
		lblsimulationResults.setBounds(6, 6, 457, 26);
		panel_1.add(lblsimulationResults);
		
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel_2.setBounds(16, 16, 287, 81);
		frmSimGame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblChoooseOpponent = new JLabel("<html>Number of Players : </html>");
		lblChoooseOpponent.setForeground(Color.RED);
		lblChoooseOpponent.setHorizontalAlignment(SwingConstants.LEFT);
		lblChoooseOpponent.setBounds(6, 6, 135, 26);
		panel_2.add(lblChoooseOpponent);
		
		txtPlayerNum = new JTextField();
		txtPlayerNum.setText("6");
		txtPlayerNum.setBounds(231, 3, 50, 28);
		panel_2.add(txtPlayerNum);
		txtPlayerNum.setColumns(10);
		
		JLabel lblnumberOfTournaments = new JLabel("<html>Number of Tournaments : </html>");
		lblnumberOfTournaments.setForeground(Color.RED);
		lblnumberOfTournaments.setHorizontalAlignment(SwingConstants.LEFT);
		lblnumberOfTournaments.setBounds(6, 45, 171, 26);
		panel_2.add(lblnumberOfTournaments);
		
		txtTournNum = new JTextField();
		txtTournNum.setText("4");
		txtTournNum.setColumns(10);
		txtTournNum.setBounds(231, 43, 50, 28);
		panel_2.add(txtTournNum);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel.setBounds(16, 109, 287, 51);
		frmSimGame.getContentPane().add(panel);
		panel.setLayout(null);
		
		
		JButton btnSimulate = new JButton("Simulate");
		btnSimulate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Get the selected number of players and tournament(s)
				myPlayNum = Integer.parseInt(txtPlayerNum.getText());
				myTournNum = Integer.parseInt(txtTournNum.getText());
				
				//clear textArea
				txtArea1.setText(null);
				txtLeader.setText(null);
				
				//Simulate the game using a randomly selected round-robin tournaments
				Project1.main(null);
				
				// Clear the textArea
				txtArea1.append(randStrategy);
				txtLeader.append(leadBoard);
				
				
			}
		});
		btnSimulate.setBounds(8, 6, 76, 35);
		panel.add(btnSimulate);
		
		JButton btnStop = new JButton("Stop");
		btnStop.setBounds(92, 6, 54, 35);
		panel.add(btnStop);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setBounds(223, 6, 54, 35);
		panel.add(btnExit);
		
		JButton button = new JButton("Clear");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtPlayerNum.setText("");
				txtTournNum.setText("");
				txtArea1.setText("");
				txtLeader.setText("");
				textSimResults.setText("");

			}
		});
		button.setBounds(154, 6, 61, 35);
		panel.add(button);
		
		
		frmSimGame.getContentPane().add(panel_3);
		
		JTextArea textArea_2 = new JTextArea();
		textArea_2.setBounds(155, 6, 0, 16);
		panel_3.add(textArea_2);
		
		JLabel lblrandomlyChosenStrategies = new JLabel("<html>RANDOMLY CHOSEN STRATEGIES </html>");
		lblrandomlyChosenStrategies.setForeground(Color.BLUE);
		lblrandomlyChosenStrategies.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		lblrandomlyChosenStrategies.setHorizontalAlignment(SwingConstants.CENTER);
		lblrandomlyChosenStrategies.setBounds(6, 6, 275, 26);
		panel_3.add(lblrandomlyChosenStrategies);
		
		JLabel lblplayer = new JLabel("<html>Player</html>");
		lblplayer.setForeground(Color.RED);
		lblplayer.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		lblplayer.setHorizontalAlignment(SwingConstants.LEFT);
		lblplayer.setBounds(6, 31, 80, 26);
		panel_3.add(lblplayer);
		
		JLabel lblstrategy = new JLabel("<html>Strategy </html>");
		lblstrategy.setForeground(Color.RED);
		lblstrategy.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		lblstrategy.setHorizontalAlignment(SwingConstants.LEFT);
		lblstrategy.setBounds(109, 31, 80, 26);
		panel_3.add(lblstrategy);
		
		JScrollPane scrollPane = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(6, 60, 275, 123);
		panel_3.add(scrollPane);
		
		
		//Display randomly chosen strategies
		scrollPane.setViewportView(txtArea1);
		txtArea1.setCaretPosition(txtArea1.getDocument().getLength());
		txtArea1.setWrapStyleWord(true);
		txtArea1.setLineWrap(true);
		txtArea1.setBackground(Color.WHITE);
		
		
		
		JLabel lblleaderBoard = new JLabel("<html>LEADER BOARD</html>");
		lblleaderBoard.setForeground(Color.BLUE);
		lblleaderBoard.setHorizontalAlignment(SwingConstants.CENTER);
		lblleaderBoard.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		lblleaderBoard.setBounds(6, 234, 275, 26);
		panel_3.add(lblleaderBoard);
		
		JLabel label_1 = new JLabel("<html>Player</html>");
		label_1.setForeground(Color.RED);
		label_1.setHorizontalAlignment(SwingConstants.LEFT);
		label_1.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		label_1.setBounds(6, 259, 80, 26);
		panel_3.add(label_1);
		
		JLabel label_2 = new JLabel("<html>Strategy </html>");
		label_2.setForeground(Color.RED);
		label_2.setHorizontalAlignment(SwingConstants.LEFT);
		label_2.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		label_2.setBounds(109, 259, 80, 26);
		panel_3.add(label_2);
		
		JLabel lblscores = new JLabel("<html>Scores </html>");
		lblscores.setForeground(Color.RED);
		lblscores.setHorizontalAlignment(SwingConstants.LEFT);
		lblscores.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		lblscores.setBounds(201, 259, 65, 26);
		panel_3.add(lblscores);
		
		JScrollPane scrollPane_1 = new JScrollPane(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane_1.setBounds(6, 283, 275, 145);
		panel_3.add(scrollPane_1);
		
		
		// Display leader board
		txtLeader.setCaretPosition(txtLeader.getDocument().getLength());
		txtLeader.setWrapStyleWord(true);
		txtLeader.setLineWrap(true);
		txtLeader.setCaretPosition(0);
		txtLeader.setBackground(Color.WHITE);
		scrollPane_1.setViewportView(txtLeader);
		
		
		
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmSimGame.dispose();
				FirstView.main(null);
			}
		});

	}
	
	
	
}
