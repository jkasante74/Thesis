package ipd;
import java.util.Comparator;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;
import java.util.Arrays;


public class Project1{
	
	// Declaration of Global variables
	public static int gameRound = 0, tourn = 0, teams;
	public static boolean flags = false;
	private static Scanner input;	
	static char [][] grimTriggerHist;
	static char [][] titForTatHist;
	static char [][] pavlovChoiceHist;
	static int [][] pavlovScoreHist;
	static char[][][] agentActionsDbase;
	public static char [] agentsActions;
	public static int [] agentsMatchScores;
	static String tempActions = "";
	public static String [] Strategy; 
	public static String[][] data;
	
	public static void main(String[] args) {

		getInput();		// Get players and Tournaments
    
		// Initializations of Global variables and objects of classes
		ArrayList<Object> myList = new ArrayList<Object>();
		ArrayList<Object> myHomeList = new ArrayList<Object>();
		ArrayList<Object> myAwayList = new ArrayList<Object>();
		AgentsAction ag = new AgentsAction();
		grimTriggerHist = new char[teams][teams];
		titForTatHist = new char[teams][teams];
		pavlovChoiceHist = new char[teams][teams];
		pavlovScoreHist = new int[teams][teams];
		agentActionsDbase = new char[tourn][teams][teams];
		data  = new String[teams][3];   // To store the final output of agents name, strategies and scores
     
		Strategy = new String[teams];
		agentsActions = new char[2];
		agentsMatchScores = new int[2];
		int []agentsTotalScores = new int[teams];
    
   
        //Create players and let them pick initial strategies
		for(int i = 0; i < teams; i++){
			myList.add(new Project1());
			Project1 obj = (Project1) myList.get(i); //create player
			Strategy[i] = Strategies.pickStrategy(i, obj, gameRound); // Player pick strategy randomly
		}
   
    
		//Print the randomly chosen strategies
		PrintOutputs.printChosenStrategies();
    
		//For each tournament  do the ff:
		for(int t = 0; t < tourn; t++){
    	   	//Print current tournament number
			PrintOutputs.printTourn(t);         
   
			// Generate the schedule using Round Robin algorithm.
			int totalRounds = (teams - 1);	 // Set total rounds to determine how many games each team plays in a tournament
			int matchesPerRound = teams / 2; //Set total matches per each  round (Note: Total matches in tournament = 0.5n(n-1) ie totalRounds * total matches)
  
            // Group players into two categories to play against each other
			for(int i = 0; i < matchesPerRound; i++){
            	myHomeList.add(new Project1());
            	myAwayList.add(new Project1());
            }	 

            //For each round in the current tournament do the following
			for(int round = 0; round < totalRounds; round++){
				gameRound = round;
    	
				//Can an agent request information about opponent? 
				requestFlagState(t, round);
    		        
				// Re-Shuffle the players to play one on one
				for (int match = 0; match < matchesPerRound; match++) {
					int home = (round + match) % (teams - 1);
					int away = (teams - 1 - match + round) % (teams - 1);

					// Last team stays in the same place while the others rotate around it.
					if (match == 0)
						away = teams - 1;
        	
					myHomeList.set(match,String.valueOf(home + 1) );
					myAwayList.set(match, String.valueOf(away + 1));
				}
    
				// State the Round Number   
				System.out.println("Round " + (round + 1));
				System.out.println();
    
				// Display the matched-paired players and their selected strategy for each rounds 
				for (int j = 0; j < matchesPerRound; j++){ 
					System.out.println("Player "+myHomeList.get(j)+ "\t vrs \t " + "Player " +myAwayList.get(j));
		   
					// Get matched-paired players action
					agentsActions = AgentsAction.getAgentsActions(t, round, myHomeList.get(j), myAwayList.get(j), Strategy);  
	
					// Calculate the agents match score	   
					agentsMatchScores = Scores.calcAgentsScores(agentsActions);
	
					// Calculate the total score for each player and store
					int scA = Integer.parseInt((String)myHomeList.get(j));
					int scB = Integer.parseInt((String)myAwayList.get(j));
					agentsTotalScores[(scA - 1)] =  agentsTotalScores[(scA - 1)] + agentsMatchScores[0];
					agentsTotalScores[(scB - 1)] =  agentsTotalScores[(scB - 1)] + agentsMatchScores[1];
					System.out.println();
    		
					// Update Strategies Histories
					Strategies.updateStrategies(scA, scB);
    		
    		
				}
	   
				System.out.println("\n");
			}
		}
  
    
       // Create a 3-dimensional array that has the Player's name, Strategies, and Score
		for(int  i = 0; i < Strategy.length; i++){
			data[i][0] = "Player "+(i +1);
			data[i][1] = Strategy[i];
			data[i][2] = String.valueOf((agentsTotalScores[i]));
		}
  
		// Sort the arrays based on the 3rd Column the total score
		Arrays.sort(data, new Comparator<String[]>() {
        
			public int compare(final String[] entry1, final String[] entry2) {
            final String time1 = entry1[2];
        	final String time2 = entry2[2];
            return Integer.valueOf(time1).compareTo(Integer.valueOf(time2));
        }
    });
    
    
		// Print Leader Board
		PrintOutputs.printLeaderBoard();

		// Print Agents Actions
		PrintOutputs.printAgentsActions();   
    
	}



	/**
	 * This sets the flag whether players can request for information about their opponents or not
	 * In the first round of Tournament 1 the flag is true which means players cannot request for information
	 * But for all other rounds the flag state changes to false and so players can request for info at a probability
	 * @param t
	 * @param round
	 * @return
	 */
	private static void requestFlagState(int t, int round) {
	
		if((t == 0)&&(round == 0))
			flags = true;
		else 
			flags = false;
	
	}



	private static void getInput() {
		
		//obtain the number of teams from user input
       input = new Scanner(System.in);
       System.out.print("How many players are in the game?");
       teams = input.nextInt();
       input = new Scanner(System.in);
       System.out.print("Enter number of tournaments to be played?");
       tourn = input.nextInt();
	
	}


	/**
	 * This methods based on a the random number generated to 
	 * determine whether the requested information about an 
	 * agent's information will be sent back to the agent or not
	 * 
	 *  
	 */
	public static String getOpponentHistory(int randomNum, int agentOppId) {
		tempActions = " ";
	
		// return opponent info if the probability value > 0
		if(randomNum >  0){
			System.out.print(randomNum + " Info available for "+ (agentOppId + 1) + " who played : ");
			
			// Look up and retrieve all the actions of the opponent agent
			for(int i = 0; i < tourn; i++){
				for(int j = 0; j < agentActionsDbase[i].length; j++)
					tempActions = tempActions + String.valueOf(agentActionsDbase[i][j][agentOppId]);
			}
	
			return tempActions;
		}
		
		else 
			System.out.println(randomNum + " Is insufficient resource to get info for " + (agentOppId + 1));
			return "  ";
		
	}


	//End of class Project1	


}