package ipd;

import java.awt.EventQueue;

import javax.swing.JFrame;

import java.awt.GridLayout;

import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JSplitPane;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.UIManager;
import java.awt.SystemColor;
import javax.swing.JSlider;
import javax.swing.border.LineBorder;
import java.awt.Color;

public class RulesSetup {

	private JFrame frmSetup;
	public static JTextField txtTemptation;
	public static JTextField txtReward;
	public static JTextField txtSucker;
	public static JTextField txtPunishment;
	public static int myTemp;
	public static int myReward;
	public static int mySucker;
	public static int myPunishment;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RulesSetup window = new RulesSetup();
					window.frmSetup.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public RulesSetup() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmSetup = new JFrame();
		frmSetup.setTitle("SetUp");
		frmSetup.setBounds(100, 100, 321, 321);
		frmSetup.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSetup.getContentPane().setLayout(new GridLayout(1, 0, 0, 0));
		
		JPanel panel = new JPanel();
		frmSetup.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel_1.setBounds(22, 17, 277, 200);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblTemptationPayoff = new JLabel("Temptation PayOff [D, C]");
		lblTemptationPayoff.setForeground(UIManager.getColor("Button.shadow"));
		lblTemptationPayoff.setHorizontalAlignment(SwingConstants.LEFT);
		lblTemptationPayoff.setBounds(21, 28, 176, 16);
		panel_1.add(lblTemptationPayoff);
		
		JLabel lblRewardPayoff = new JLabel("Reward PayOff [C, C]");
		lblRewardPayoff.setForeground(UIManager.getColor("Button.shadow"));
		lblRewardPayoff.setHorizontalAlignment(SwingConstants.LEFT);
		lblRewardPayoff.setBounds(21, 70, 176, 16);
		panel_1.add(lblRewardPayoff);
		
		JLabel lblPunishmentPayoff = new JLabel("Punishment PayOff [D, D]");
		lblPunishmentPayoff.setForeground(UIManager.getColor("Button.shadow"));
		lblPunishmentPayoff.setHorizontalAlignment(SwingConstants.LEFT);
		lblPunishmentPayoff.setBounds(21, 154, 176, 16);
		panel_1.add(lblPunishmentPayoff);
		
		JLabel lblSuckerPayoff = new JLabel("Sucker's PayOff [C, D]");
		lblSuckerPayoff.setForeground(UIManager.getColor("Button.shadow"));
		lblSuckerPayoff.setHorizontalAlignment(SwingConstants.LEFT);
		lblSuckerPayoff.setBounds(21, 112, 176, 16);
		panel_1.add(lblSuckerPayoff);
		
		txtTemptation = new JTextField();
		txtTemptation.setText("5");
		txtTemptation.setColumns(10);
		txtTemptation.setBounds(209, 22, 44, 28);
		panel_1.add(txtTemptation);
		
		txtReward = new JTextField();
		txtReward.setText("3");
		txtReward.setColumns(10);
		txtReward.setBounds(209, 64, 44, 28);
		panel_1.add(txtReward);
		
		txtSucker = new JTextField();
		txtSucker.setText("0");
		txtSucker.setColumns(10);
		txtSucker.setBounds(209, 106, 44, 28);
		panel_1.add(txtSucker);
		
		txtPunishment = new JTextField();
		txtPunishment.setText("1");
		txtPunishment.setColumns(10);
		txtPunishment.setBounds(209, 148, 44, 28);
		panel_1.add(txtPunishment);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel_3.setBounds(22, 229, 277, 50);
		panel.add(panel_3);
		panel_3.setLayout(null);
		
		// initialize variables
		 myTemp = Integer.parseInt(txtTemptation.getText());
		 myReward = Integer.parseInt(txtReward.getText());
		 mySucker = Integer.parseInt(txtSucker.getText());
		 myPunishment = Integer.parseInt(txtPunishment.getText());
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				// Update random simulation scores
				Scores.temptation = Integer.parseInt(txtTemptation.getText());
				Scores.reward = Integer.parseInt(txtReward.getText());
				Scores.sucker = Integer.parseInt(txtSucker.getText());
				Scores.punishment = Integer.parseInt(txtPunishment.getText());
				
				// Update one on one game scores
				OneOnOne.temptation = Integer.parseInt(txtTemptation.getText());
				OneOnOne.reward = Integer.parseInt(txtReward.getText());
				OneOnOne.sucker = Integer.parseInt(txtSucker.getText());
				OneOnOne.punishment = Integer.parseInt(txtPunishment.getText());
			
				// Update customized simulation scores
				CusScores.temptation = Integer.parseInt(txtTemptation.getText());
				CusScores.reward = Integer.parseInt(txtReward.getText());
				CusScores.sucker = Integer.parseInt(txtSucker.getText());
				CusScores.punishment = Integer.parseInt(txtPunishment.getText());
				
				
			}
		});
		btnSave.setBounds(5, 6, 58, 38);
		panel_3.add(btnSave);
		
		JButton btnCancel = new JButton("Clear");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtTemptation.setText("");
				txtReward.setText("");
				txtSucker.setText("");
				txtPunishment.setText("");
			}
		});
		btnCancel.setBounds(68, 6, 61, 38);
		panel_3.add(btnCancel);
		
		JButton btnDefault = new JButton("Default");
		btnDefault.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtTemptation.setText("5");
				Scores.temptation = 5;
				txtReward.setText("3");
				Scores.reward = 3;
				txtSucker.setText("0");
				Scores.sucker = 0;
				txtPunishment.setText("1");
				Scores.punishment = 1;
			}
		});
		btnDefault.setBounds(134, 6, 72, 38);
		panel_3.add(btnDefault);
		
		JButton button = new JButton("Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmSetup.dispose();
				String[] args = null;
				FirstView.main(args);
			}
		});
		button.setBounds(211, 6, 61, 38);
		panel_3.add(button);
	}
}
