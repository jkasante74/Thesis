package ipd;

import java.util.Random;

public class OneOnOneStrategies {
	public static char actionA;
	public static char pavlovChoioce = 'C';
	
	public static char oppAction(String a){
		if(a.equalsIgnoreCase("CooperateAll")) 
			actionA = cooperateAll(); 
		if(a.equalsIgnoreCase("DefectAll"))  	
			actionA = defectAll();
	
	if(a.equalsIgnoreCase("Random")) 
		actionA = random();
	
	if(a.equalsIgnoreCase("TitForTat"))	
		actionA = TitForTat();
	
	if(a.equalsIgnoreCase("PAVLOV")) 
		actionA = PAVLOV();
	
	if(a.equalsIgnoreCase("GrimTrigger")) 
		actionA = grimTrigger(); 
	
		return actionA;
	
	}
	

	/**
	 * This describes the Grim Trigger Strategy.
	 * Initially, a player using grim trigger will cooperate, 
	 * but as soon as the opponent defects (thus satisfying the 
	 * trigger condition), the player using grim trigger will 
	 * defect for the remainder of the iterated game / tournament. 
	 * @return
	 */	
	public static char grimTrigger() {
		// create an array of strategies
		// before selection of c or d get the opponent id
		char grimSelection;
		if (OneOnOne.gTrigger=='D')
			grimSelection = 'D';
			
		else
			grimSelection = 'C';
			
		return grimSelection;
	}



/**
* This method describes the PAVLOV Strategy. 
* The idea here is that the agent repeat last choice if good outcome - 
* If 5 or 3 points scored in the last round then repeat 
* last choice.
* @param n
* @param oppId
* @return
*/
static char PAVLOV() {
	
		
	if (PlayGame.counter == 1){
		pavlovChoioce = 'C';	//cooperate by default
		return pavlovChoioce;
	}
	
	if(OneOnOne.pScore >= 3){
		return pavlovChoioce;
	}
		
	else{
		if(pavlovChoioce == 'C')
			pavlovChoioce = 'D';
		else
			pavlovChoioce = 'C';
		
		return pavlovChoioce;
	}
}

	



/**
* This method describes the TitForTat Strategy 
* Cooperate at the first play; then,
* on subsequent plays, mimic the action
* the other player chose on the immediately 
* preceding play
* @param n
* @param oppId
* @return
*/

static char TitForTat() {
	char myTFT;
			
	if (OneOnOne.TFT == 'D')
		myTFT = 'D';
		
	else
		myTFT= 'C';
			
	return myTFT;
		
}

	
/**
* This method describes the Defect all Strategy. 
* Here, an defect at all times no matter what the opponent does
* @return char
 */
static char defectAll(){
			
	return 'D';
}
		
	


/**
* This method describes the Corporate All Strategy. 
* Here an agent cooperate at all times no matter what the opponent does
* @return char
*/
static char cooperateAll(){
	
return 'C';
}




/**
* This method describes the Random Strategy. 
* Here an agent chooses to Cooperate or Defect based on a randomly generated 
* floating point number between 0 and 1. 
* If random number < 0.5, then the agent cooperate, else the agent defects
* @return
*/
static char random(){
	
	// Generate a random number to determine whether to cooperate or defect
	if (Math.random() < 0.5)
			return 'C';  //cooperates half the time
		else
			return 'D';  //defects half the time
}





	
	
}
