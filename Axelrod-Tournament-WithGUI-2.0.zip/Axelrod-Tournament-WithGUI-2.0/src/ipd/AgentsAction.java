package ipd;

import java.util.Random;

/**
 * Get the actions associated with the strategies of the agents in the current match
 * @param object
 * @param object2
 * @param strategy
 */

public class AgentsAction {

	

	 Strategies stra = new Strategies();
	Project1 pro = new Project1();
	
	/**
	 * Get the actions of the agents when they play their pure strategies
	 * @param t
	 * @param cRound
	 * @param object
	 * @param object2
	 * @param strategy
	 * @return
	 */
	public static char[] getAgentsPureActions(int t, int cRound, Object object, Object object2, String[] strategy) {
		char [] actions = new char[2];
		String a = strategy[(Integer.parseInt((String)object) - 1)];
		String b = strategy[(Integer.parseInt((String)object2) - 1)];
		int agentId = (Integer.parseInt((String)object) - 1);
		int agentOppId = (Integer.parseInt((String)object2) - 1);
		
		// Print the competing strategies if the matching agents doesn't include Dummy
		if(!b.contains("Dummy")){
			System.out.println(a +"\t vrs \t" + b);
			String strs = a +"\t vrs \t" + b + "\n";
			SimGame.textSimResults.append(strs);
		}
		// get the Action
		char actionA = 0, actionB = 0;
	/*		 
		switch (a) {
			case "CooperateAll": actionA = Strategies.cooperateAll(agentOppId); break;
			case "DefectAll": 	actionA = Strategies.defectAll(agentOppId); break;
			case "TitForTat":	actionA = Strategies.TitForTat(cRound, agentId, agentOppId); break;
			case "Random": actionA = Strategies.random( agentOppId) ; break;
			case "Pavlov": actionA = Strategies.PAVLOV(cRound, agentId,agentOppId); break;
			case "GrimTrigger": actionA = Strategies.grimTrigger(agentId,agentOppId);  break;
			default: throw new RuntimeException("Bad argument passed to makePlayer");
		}
			 
		switch (b) {
		case "CooperateAll": actionB = Strategies.cooperateAll(agentId); break;
		case "DefectAll": 	actionB = Strategies.defectAll(agentId); break;
		case "TitForTat":	actionB = Strategies.TitForTat(cRound, agentOppId, agentId); break;
		case "Random": actionB =Strategies.random(agentId) ; break;
		case "Pavlov": actionB = Strategies.PAVLOV(cRound, agentOppId,agentId); break;
		case "GrimTrigger": actionB = Strategies.grimTrigger(agentOppId,agentId);  break;
		default: throw new RuntimeException("Bad argument passed to makePlayer");
		}	 
		*/
		
	if(a.equalsIgnoreCase("CooperateAll")) 
			actionA = Strategies.cooperateAll(agentOppId); 
	if(a.equalsIgnoreCase("DefectAll"))  	
		actionA = Strategies.defectAll(agentOppId);
	if(a.equalsIgnoreCase("TitForTat"))	
		actionA = Strategies.TitForTat(cRound, agentId, agentOppId);
	if(a.equalsIgnoreCase("Random")) 
		actionA = Strategies.random( agentOppId);
	if(a.equalsIgnoreCase("Pavlov")) 
		actionA = Strategies.PAVLOV(cRound, agentId,agentOppId);
	if(a.equalsIgnoreCase("GrimTrigger")) 
		actionA = Strategies.grimTrigger(agentId,agentOppId); 
	if(a.equalsIgnoreCase("Dummy")) 
		actionA = Strategies.dummy(); 
	
	
	if(b.equalsIgnoreCase("CooperateAll")) 
		actionB = Strategies.cooperateAll(agentId); 
	if(b.equalsIgnoreCase("DefectAll")) 
		actionB = Strategies.defectAll(agentId);
	if(b.equalsIgnoreCase("TitForTat"))	
		actionB = Strategies.TitForTat(cRound, agentOppId, agentId); 
	if(b.equalsIgnoreCase("Random")) 
		actionB =Strategies.random(agentId);
	if(b.equalsIgnoreCase("Pavlov")) 
		actionB = Strategies.PAVLOV(cRound, agentOppId,agentId);
	if(b.equalsIgnoreCase("GrimTrigger")) 
		actionB = Strategies.grimTrigger(agentOppId,agentId); 
	if(b.equalsIgnoreCase("Dummy")) 
		actionB = Strategies.dummy();
	
			 actions[0] = actionA;   // agentId
			 actions[1] = actionB;   // agentOppId
			
			 // Don't show the actions if there is a dummy player
			 if(!b.contains("Dummy")){
				 System.out.println(actions[0] +"\t \t vrs \t \t" + actions[1]);	// Print actions of agents and competition
				 String str = actions[0] +"\t vrs \t" + actions[1] + "\n";
				 SimGame.textSimResults.append(str);
			 }
			 
			 
		return actions;
	}
	

	
	public static char getSingleAgentPureActions(int t, int cRound, Object object, Object object2, String[] strategy, int i) {
		
		String a = strategy[(Integer.parseInt((String)object) - 1)]; // Get strategy of the agent
	//	String b = strategy[(Integer.parseInt((String)object2) - 1)]; // Get the strategy of the opponent
		int agentId = (Integer.parseInt((String)object) - 1); //Get the agent id
		int agentOppId = (Integer.parseInt((String)object2) - 1); // Get the opponent id
	//	System.out.println(a +"\t vrs \t" + b);
		
		// get the Action
		char actionA = 0;
		/*	 
		switch (a) {
			case "CooperateAll": actionA = Strategies.cooperateAll(agentOppId); break;
			case "DefectAll": 	actionA = Strategies.defectAll(agentOppId); break;
			case "TitForTat":	actionA = Strategies.TitForTat(cRound, agentId, agentOppId); break;
			case "Random": actionA = Strategies.random( agentOppId) ; break;
			case "Pavlov": actionA = Strategies.PAVLOV(cRound, agentId,agentOppId); break;
			case "GrimTrigger": actionA = Strategies.grimTrigger(agentId,agentOppId);  break;
			default: throw new RuntimeException("Bad argument passed to makePlayer");
		}*/
		
		if(a.equalsIgnoreCase("CooperateAll")) 
			actionA = Strategies.cooperateAll(agentOppId); 
	if(a.equalsIgnoreCase("DefectAll"))  	
		actionA = Strategies.defectAll(agentOppId);
	if(a.equalsIgnoreCase("TitForTat"))	
		actionA = Strategies.TitForTat(cRound, agentId, agentOppId);
	if(a.equalsIgnoreCase("Random")) 
		actionA = Strategies.random( agentOppId);
	if(a.equalsIgnoreCase("Pavlov")) 
		actionA = Strategies.PAVLOV(cRound, agentId,agentOppId);
	if(a.equalsIgnoreCase("GrimTrigger")) 
		actionA = Strategies.grimTrigger(agentId,agentOppId); 
	if(a.equalsIgnoreCase("Dummy")) 
		actionA = Strategies.dummy(); 
		return actionA;
	}
	
	
	/**
	 *  This method Checks if an agent has the right to request for information about their agent or not
	 *  A generated number of 1 indicates that agent can request info
	 *  A generated number of 0 means that agent cannot request info.
	 *  
	 */
	public static int[] randomNumGen(Object object, Object object2){
			
			Random randomGenerator = new Random();
			int []randomNum = new int[2];
			 randomNum[0] = randomGenerator.nextInt(2);
			 randomNum[1] = randomGenerator.nextInt(2);
		  return randomNum;	
	}
	


/**
 * In this method, Agents' take strategic actions based on the past moves of their opponents
*/

	public static char getStrategicActions(Object object, int i){
	
		// Declare variables
		char [] agentsActions = new char [2];
		
		int agentOppId = (Integer.parseInt((String)object) - 1);
	
		//Player 1 takes Strategic Action
		String opponent1 = Project1.getOpponentHistory(agentOppId); //Player 1 request for information about opponent player 2
		int oppAgentCount [] = Scores.countAgentActions(opponent1); //Count Cooperation and Defections made by the opponent
		System.out.println(opponent1 + " [ C is " + oppAgentCount[0] + " and D is "+ oppAgentCount[1] + " ]"); //Display
		System.out.println();	
		String Mystr = opponent1 + " [ C is " + oppAgentCount[0] + " and D is "+ oppAgentCount[1] + " ]" + "\n";
	     SimGame.textSimResults.append(Mystr);
		
		//  Player 1 takes an action based on Player 2 past actions
		if(oppAgentCount[0] > oppAgentCount[1]) // Take an Action 'C' if opponent cooperates more than defects historically
			agentsActions[i] =	'C';

		if(oppAgentCount[0] < oppAgentCount[1]) // Take an Action 'D' if opponent cooperates more than defects historically
			agentsActions[i] = 'D';

		if(oppAgentCount[0] == oppAgentCount[1]) // Take an Action 'C' if opponent cooperates as much as defects historically
			agentsActions[i] =	'C';
		
			return agentsActions[i];
	}


	
	
	
	
	
	
	
	
}