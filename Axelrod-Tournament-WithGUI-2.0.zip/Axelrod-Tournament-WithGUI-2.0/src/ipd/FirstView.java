package ipd;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.GridLayout;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JSplitPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;

public class FirstView {

	private JFrame frmFirstView;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FirstView window = new FirstView();
					window.frmFirstView.setVisible(true);
					window.frmFirstView.setEnabled(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FirstView() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmFirstView = new JFrame();
		frmFirstView.setTitle("First View");
		frmFirstView.setBounds(100, 100, 525, 107);
		frmFirstView.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmFirstView.getContentPane().setLayout(new GridLayout(1, 0, 0, 0));
		
		JPanel panel = new JPanel();
		frmFirstView.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(19, 17, 483, 53);
		panel.add(panel_3);
		panel_3.setLayout(null);
		
		JButton btnPlaygAME = new JButton("Play Opponent");
		btnPlaygAME.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String [] args = null;
				PlayGame.main(args);
				frmFirstView.setVisible(false);
			}
		});
		btnPlaygAME.setBounds(10, 5, 108, 41);
		panel_3.add(btnPlaygAME);
		
		JButton btnCustomTourn = new JButton("<html>Custom Tournament </html>");
		btnCustomTourn.setVerticalAlignment(SwingConstants.TOP);
		btnCustomTourn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String [] args = null;
				CustomizeGame.main(args);
				frmFirstView.setVisible(false);
				
			}
		});
		btnCustomTourn.setBounds(128, 5, 108, 41);
		panel_3.add(btnCustomTourn);
		
		JButton btnSimulation = new JButton("<html>Random Simulation</html>");
		btnSimulation.setVerticalAlignment(SwingConstants.TOP);
		btnSimulation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				frmFirstView.setVisible(false);
				SimGame.main(null);
				
			}
		});
		btnSimulation.setBounds(246, 5, 108, 41);
		panel_3.add(btnSimulation);
		
		JButton btnSetUp = new JButton("SetUp");
		btnSetUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String [] args = null;
				RulesSetup.main(args);
				frmFirstView.setEnabled(false);
				
			}
		});
		btnSetUp.setBounds(364, 5, 108, 41);
		panel_3.add(btnSetUp);
	}
}
