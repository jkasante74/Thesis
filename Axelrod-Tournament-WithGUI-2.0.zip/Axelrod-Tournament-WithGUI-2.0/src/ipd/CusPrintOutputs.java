package ipd;

public class CusPrintOutputs {

	/**
	 * This method prints the heading for the current Tournament played
	 * @param t
	 */
	public static String message = "";
	public static String message1 = "";
	
	
	public static void printTourn(int t){
		System.out.println("\nROUND-ROBIN TOURNAMENT "+ (t+1));
    	System.out.println("===================");
    	String str = "\nROUND-ROBIN TOURNAMENT "+ (t+1) +"\n"+ "===================\n";
    	CustomizeGame.textSimResults.append(str);
	}
	

	
	/**
	 * This method prints the Leader Board showing players, their randomly chosen strategies 
	 * and the total pay-offs at the end of the tournament. 
	 */
	public static void printLeaderBoard(){
		System.out.println("LEADER BOARD (Variation of IPD)");
		System.out.println("=================================");
		
		//Print out of leader board if number of players is even
		if(CustomizeGame.myPlayerNum % 2 == 0){
			for(int i = (CusGame.data.length-1); i >= 0;i--){
				message1 = message1 + CusGame.data[i][0] + "\t" + CusGame.data[i][1] + "\t" +  CusGame.data[i][2] + "\n";
				CustomizeGame.leadBoard = message1;
				System.out.printf("%-20s%-30s%-30s", CusGame.data[i][0], CusGame.data[i][1], CusGame.data[i][2]);
				System.out.println();
			}
			message1 = "";
		}
		
		//Print out of leader board if number of players is odd
		else{
				for(int i = (CusGame.data.length-1); i > 0;i--){
					message1 = message1 + CusGame.data[i][0] + "\t" + CusGame.data[i][1] + "\t" +  CusGame.data[i][2] + "\n";
					CustomizeGame.leadBoard = message1;
					System.out.printf("%-20s%-30s%-30s", CusGame.data[i][0], CusGame.data[i][1], CusGame.data[i][2]);
					System.out.println();
				}
				message1 = "";
			
		}
		
		
		
		
	}                              
  
	
	
    /**
     * Let's print the actions taken by all agents
     */
	public static void printAgentsActions(){
		for(int h = 0; h < CusGame.tourn; h++){
			for(int i = 0; i < CusGame.teams; i++){
				for(int j=0 ; j < CusGame.teams; j++)
					System.out.print(CusGame.agentActionsDbase[h][i][j]+ "\t");
				System.out.println();
			}
			System.out.println("\n");
		}
	}
	
	
	
	
	
	
	
	
}
