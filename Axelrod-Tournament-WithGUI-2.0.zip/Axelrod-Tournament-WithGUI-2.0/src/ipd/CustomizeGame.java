package ipd;

import java.awt.EventQueue;

import javax.swing.JFrame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Color;

import javax.swing.border.LineBorder;

import java.awt.Font;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

public class CustomizeGame {

	private JFrame frmCusGame;
	private JTextField txtTournNum;
	public static int myPlayerNum = 0;
	public static int myTournNum;
	public static String [] agentStrategy;
	public static String leadBoard;
	public static JTextArea textSimResults = new JTextArea();
	public static final JTextArea txtMyLeader = new JTextArea(5, 26);
	public static final ArrayList<String> cusStrategy = new ArrayList<String>();
	final JFileChooser fc = new JFileChooser();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomizeGame window = new CustomizeGame();
					window.frmCusGame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CustomizeGame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		
		
		frmCusGame = new JFrame();
		frmCusGame.setResizable(false);
		frmCusGame.setTitle("Customized Simulation");
		frmCusGame.setBounds(100, 100, 790, 686);
		frmCusGame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmCusGame.getContentPane().setLayout(null);
	
		final JTextArea txtmyStra = new JTextArea(5, 16);
		txtmyStra.setForeground(new Color(221, 160, 221));

		
		txtMyLeader.setForeground(new Color(189, 183, 107));
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel_1.setBounds(315, 16, 457, 630);
		frmCusGame.getContentPane().add(panel_1);
		txtMyLeader.setText(null);
		textSimResults.setText(null);
		
		panel_1.setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(155, 6, 0, 16);
		panel_1.add(textArea);
		
		JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		panel_3.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel_3.setBounds(16, 219, 287, 427);
		
		JScrollPane scrollPane_2 = new JScrollPane(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scrollPane_2.setBounds(6, 40, 444, 584);
		panel_1.add(scrollPane_2);
		textSimResults.setForeground(new Color(105, 105, 105));
		textSimResults.setFont(new Font("Lucida Grande", Font.PLAIN, 12));
		
		
		scrollPane_2.setViewportView(textSimResults);
		
		JLabel lblsimulationResults = new JLabel("<html>Customized Simulation Results </html>");
		lblsimulationResults.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		lblsimulationResults.setForeground(Color.RED);
		lblsimulationResults.setHorizontalAlignment(SwingConstants.CENTER);
		lblsimulationResults.setBounds(6, 6, 457, 26);
		panel_1.add(lblsimulationResults);
		
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel_2.setBounds(16, 16, 287, 81);
		frmCusGame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblChoooseOpponent = new JLabel("<html>Add Player : </html>");
		lblChoooseOpponent.setBounds(6, 4, 85, 26);
		panel_2.add(lblChoooseOpponent);
		lblChoooseOpponent.setForeground(Color.RED);
		lblChoooseOpponent.setHorizontalAlignment(SwingConstants.LEFT);
		
		final JComboBox<Object> cmbStrat = new JComboBox<Object>();
		cmbStrat.setModel(new DefaultComboBoxModel<Object>(new String[] {"CooperateAll", "DefectAll", "GrimTrigger", "PAVLOV", "Random", "TitForTat"}));
		cmbStrat.setBounds(91, 6, 190, 27);
		panel_2.add(cmbStrat);
		
		
		JButton btnAdd = new JButton("Add Player");
		btnAdd.setBounds(91, 42, 82, 33);
		panel_2.add(btnAdd);
		
		JButton btnClear = new JButton("Clear");
		btnClear.setBounds(205, 41, 76, 35);
		panel_2.add(btnClear);
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cusStrategy.clear();
				txtmyStra.setText(null);
				txtMyLeader.setText(null);
				textSimResults.setText(null);
				myPlayerNum = 0;
				
			}
		});
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				//Get the selected agent strategy and Add to the ArrayList
				String strat = (String) cmbStrat.getSelectedItem();
				cusStrategy.add(strat);
			
				// Show the added player strategy in the customized Strategy List
				txtmyStra.append("Player "+ (myPlayerNum + 1) + "\t"+ strat + "\n");
				
				//Increase the number of agents
				myPlayerNum++;
				
				try{
				myTournNum = Integer.parseInt(txtTournNum.getText());
				}
				catch(NumberFormatException nfe){
					JOptionPane.showMessageDialog(null, "Please Enter number of Tournament(s)");
				}
				// Clear the textArea
				txtMyLeader.append("");
				
				
			}
		});
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel.setBounds(16, 109, 287, 38);
		frmCusGame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblnumberOfTournaments = new JLabel("<html>Number of Tournaments : </html>");
		lblnumberOfTournaments.setBounds(6, 6, 171, 26);
		panel.add(lblnumberOfTournaments);
		lblnumberOfTournaments.setForeground(Color.RED);
		lblnumberOfTournaments.setHorizontalAlignment(SwingConstants.LEFT);
		
		txtTournNum = new JTextField();
		txtTournNum.setBounds(231, 5, 50, 28);
		panel.add(txtTournNum);
		txtTournNum.setText("4");
		txtTournNum.setColumns(10);
		
		
		frmCusGame.getContentPane().add(panel_3);
		
		JTextArea textArea_2 = new JTextArea();
		textArea_2.setBounds(155, 6, 0, 16);
		panel_3.add(textArea_2);
		
		JLabel lblrandomlyChosenStrategies = new JLabel("<html>CUSTOMIZED STRATEGIES </html>");
		lblrandomlyChosenStrategies.setForeground(Color.BLUE);
		lblrandomlyChosenStrategies.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		lblrandomlyChosenStrategies.setHorizontalAlignment(SwingConstants.CENTER);
		lblrandomlyChosenStrategies.setBounds(6, 6, 275, 26);
		panel_3.add(lblrandomlyChosenStrategies);
		
		JLabel lblplayer = new JLabel("<html>Player</html>");
		lblplayer.setForeground(Color.RED);
		lblplayer.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		lblplayer.setHorizontalAlignment(SwingConstants.LEFT);
		lblplayer.setBounds(6, 31, 80, 26);
		panel_3.add(lblplayer);
		
		JLabel lblstrategy = new JLabel("<html>Strategy </html>");
		lblstrategy.setForeground(Color.RED);
		lblstrategy.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		lblstrategy.setHorizontalAlignment(SwingConstants.LEFT);
		lblstrategy.setBounds(109, 31, 80, 26);
		panel_3.add(lblstrategy);
		
		JScrollPane scrollPane = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(6, 55, 275, 139);
		panel_3.add(scrollPane);
		
		
		//Display randomly chosen strategies
		scrollPane.setViewportView(txtmyStra);
		txtmyStra.setCaretPosition(txtmyStra.getDocument().getLength());
		txtmyStra.setWrapStyleWord(true);
		txtmyStra.setLineWrap(true);
		txtmyStra.setBackground(Color.WHITE);
		
		
		
		JLabel lblleaderBoard = new JLabel("<html>LEADER BOARD</html>");
		lblleaderBoard.setForeground(Color.BLUE);
		lblleaderBoard.setHorizontalAlignment(SwingConstants.CENTER);
		lblleaderBoard.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		lblleaderBoard.setBounds(6, 217, 275, 26);
		panel_3.add(lblleaderBoard);
		
		JLabel label_1 = new JLabel("<html>Player</html>");
		label_1.setForeground(Color.RED);
		label_1.setHorizontalAlignment(SwingConstants.LEFT);
		label_1.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		label_1.setBounds(6, 242, 80, 26);
		panel_3.add(label_1);
		
		JLabel label_2 = new JLabel("<html>Strategy </html>");
		label_2.setForeground(Color.RED);
		label_2.setHorizontalAlignment(SwingConstants.LEFT);
		label_2.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		label_2.setBounds(109, 242, 80, 26);
		panel_3.add(label_2);
		
		final JButton btnExport = new JButton("Export");
		
		JLabel lblscores = new JLabel("<html>Scores </html>");
		lblscores.setForeground(Color.RED);
		lblscores.setHorizontalAlignment(SwingConstants.LEFT);
		lblscores.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		lblscores.setBounds(201, 242, 65, 26);
		panel_3.add(lblscores);
		
		JScrollPane scrollPane_1 = new JScrollPane(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane_1.setBounds(6, 267, 275, 154);
		panel_3.add(scrollPane_1);
		
		
		// Display leader board
		txtMyLeader.setCaretPosition(txtMyLeader.getDocument().getLength());
		txtMyLeader.setWrapStyleWord(true);
		txtMyLeader.setLineWrap(true);
		txtMyLeader.setCaretPosition(0);
		txtMyLeader.setBackground(Color.WHITE);
		scrollPane_1.setViewportView(txtMyLeader);
		
		
		btnExport.setEnabled(false);
		
		JPanel panel_4 = new JPanel();
		panel_4.setLayout(null);
		panel_4.setBorder(new LineBorder(Color.LIGHT_GRAY));
		panel_4.setBounds(16, 161, 287, 46);
		frmCusGame.getContentPane().add(panel_4);
		
		JButton btnSimulate = new JButton("Simulate");
		btnSimulate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				// check if tournament number has been added
				try{
					myTournNum = Integer.parseInt(txtTournNum.getText());
					}
					catch(NumberFormatException nfe){
						JOptionPane.showMessageDialog(null, "Please Enter number of Tournament(s)");
					}
				
				
				// Check if any agent has been added
				if(myPlayerNum == 0)
					JOptionPane.showMessageDialog(null, "Please add players");
				
				
				else{
					// Ensure leader board and Result textbox are empty
					txtMyLeader.setText(null);
					textSimResults.setText(null);
				
					// Get the tournament number
					myTournNum = Integer.parseInt(txtTournNum.getText());
				
				
					//Convert customized strategy into an array
					agentStrategy = cusStrategy.toArray(new String[cusStrategy.size()]);
				
					
					
					// Run the project
					CusGame.main(null);
			
					// Display the results in the leader board
					txtMyLeader.append(leadBoard);
					
					//Activate Export button
					btnExport.setEnabled(true);
				
				}
			}
		});
		btnSimulate.setBounds(10, 6, 92, 35);
		panel_4.add(btnSimulate);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmCusGame.dispose();
				cusStrategy.clear();
				txtmyStra.setText(null);
				txtMyLeader.setText(null);
				textSimResults.setText(null);
				myPlayerNum = 0;
				String[] args = null;
				
				FirstView.main(args);
			}
		});
		btnBack.setBounds(204, 6, 76, 35);
		panel_4.add(btnBack);
		
		
		btnExport.setBounds(115, 7, 76, 33);
		panel_4.add(btnExport);
		btnExport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Report Heading
				String Lead1 = "CUSTOMIZED STRATEGY \nPlayer \t\tStrategy \n========================== ";
				String Lead2 = "LEADER BOARD \nPlayer \t\tStrategy \tScore\n==================================== ";
				String Lead3 = "-------DETAILED RESULTS--------- \n";
				
				// Store information to Export	
				String output1 = txtmyStra.getText();
				String output2 = txtMyLeader.getText();
				String output3 = textSimResults.getText();
				String output4 = "Number of Tournaments : " + myTournNum;
				String filename = "Customized Simulation Result.csv";
				
				FileWriter fstream;
				try {
				    File file = new File(filename);
				    
				    // checking if we can write this file
				    System.out.println("Can write? " + file.canWrite());
				    fstream = new FileWriter(file);
				    BufferedWriter out = new BufferedWriter(fstream);
				    out.write(Lead1);
				    out.newLine();
				    out.write(output1);
				    out.newLine();
				    out.newLine();
				    out.newLine();
				    out.write(Lead2);
				    out.newLine();
				    out.write(output2);
				    out.newLine();
				    out.newLine();
				    out.newLine();
				    out.write(Lead3);
				    out.newLine();
				    out.write(output4);
				    out.newLine();
				    out.newLine();
				    out.write(output3);
				    out.newLine();
				    
				    out.flush();
				    out.close();
				    JOptionPane.showMessageDialog(null, "Results Export Complete");
				} catch (IOException e1) {
				    e1.printStackTrace();
				}
			}
		});

	}
}
