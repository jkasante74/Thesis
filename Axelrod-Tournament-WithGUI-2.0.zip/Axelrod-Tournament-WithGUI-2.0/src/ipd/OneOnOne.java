package ipd;

public class OneOnOne {

	public static int rNum;
	public static String oppAgent;
	public static String playerAction;
	public static int totalScoreA = 0, totalScoreB = 0;
	public static char TFT;
	public static char gTrigger;
	public static int pScore;
	public static int temptation = RulesSetup.myTemp;
	public static int reward = RulesSetup.myReward;
	public static int sucker = RulesSetup.mySucker;
	public static int punishment = RulesSetup.myPunishment;
	/**
	 * Main method
	 * @param args
	 */
	public static void main(String[] args) {
		
		RulesSetup myRule = new RulesSetup();
		
		// Get opponent action
		char oppAct = OneOnOneStrategies.oppAction(args[2]);
		
		String result = args[0]+ "\t"+args[1]+"\t"+oppAct + "\n";
		PlayGame.txtResults.append(result);
	
		String myAct = args[1];
		char myActs = myAct.charAt(0);
		char [] actions = {myActs,oppAct}; 
		//System.out.println(actions[0]+"\t"+actions[1]);
		// Calculate agents actions
		int scores[] = calcAgentsScores(actions);
	//	System.out.println(scores[0]+"\t"+scores[1]);
		
		calcTotalScores(scores);
		updateOpponentHist(actions, scores);
		
		
	}
	
	
	
	private static void updateOpponentHist(char[] actions, int [] scores) {
		
		//char player = actions[0];
		//char opponent = actions[1];
		
		TFT = actions[0];
		
		if(actions[0] == 'D')
			gTrigger = 'D';
		
		pScore = scores[1];
		
	}



	/**
	 * This method calculates the payoffs associated with the selected actions
	 * @param agentsActions
	 * @return
	 */

		public static int [] calcAgentsScores(char[] agentsActions) {
			
			
			
			int scoreA = 0, scoreB = 0;
			int []matchScores = new int[2];
		
			if((agentsActions[0]=='C')&&(agentsActions[1]=='C')){
				scoreA = reward;
				scoreB = reward;
			}
		
			if((agentsActions[0]=='C')&&(agentsActions[1]=='D')){
				scoreA = sucker; 
				scoreB = temptation;
			}
		
			if((agentsActions[0]=='D')&&(agentsActions[1]=='C')){
				scoreA = temptation;
				scoreB = sucker;
			}
		
			if((agentsActions[0]=='D')&&(agentsActions[1]=='D')){
				scoreA = punishment; 
				scoreB = punishment;
			}
		
			matchScores[0] = scoreA;
			matchScores[1] = scoreB;
		//	System.out.println(agentsActions);
			
		
			return matchScores;
		}
	
	
		/**
		 * This method calculates the total payoffs for both user and opponent
		 * @param agentsActions
		 * @return
		 */

			public static void calcTotalScores(int[] scores) {
				totalScoreA = totalScoreA + scores[0];
				totalScoreB = totalScoreB + scores[1];
				
				String totalResults = "Total: \t"+ totalScoreA + "\t" + totalScoreB;
		//		System.out.println(totalResults);
				PlayGame.txtTotal.setText(totalResults);;
			}
		
		
		
	
}
	